def LengthOfName(Name):
    return len(Name)

def main():
    Name = input("Enter a name : ")
    print ("The length of the entered name is ",LengthOfName (Name))

if __name__ == "__main__":
    main()