def Display():
    for i in range(5):
        print("Marvellous")

def main():
    Display()

if __name__ == "__main__":
    main()