def Fun():
    print("Hello from fun.!")

def main():
    Fun()

if __name__ == "__main__":
    main()