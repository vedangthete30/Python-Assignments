def Display():
    for i in range(10, 0, -1):
        print(i, end = " ")

def main():
    print("Display 10 to 1")
    Display()

if __name__ == "__main__":
    main()